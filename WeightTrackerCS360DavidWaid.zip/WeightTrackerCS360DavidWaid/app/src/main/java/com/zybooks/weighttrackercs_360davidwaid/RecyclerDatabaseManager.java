package com.zybooks.weighttrackercs_360davidwaid;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

public class RecyclerDatabaseManager {
    private RecyclerDatabaseHelper dbHelper;
    private SQLiteDatabase database;

    public RecyclerDatabaseManager(Context context) {
        dbHelper = new RecyclerDatabaseHelper(context);
    }

    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        logAllRecords();
        dbHelper.close();
    }



    public long insertWeightAndDate(String date, String weight) {
        ContentValues values = new ContentValues();
        values.put(RecyclerDatabaseHelper.COLUMN_WEIGHT, weight);
        values.put(RecyclerDatabaseHelper.COLUMN_DATE, date);
        return database.insert(RecyclerDatabaseHelper.TABLE_NAME, null, values);
    }

    // Update method for editing
    public int updateWeightAndDate(long id, String date, String weight) {
        ContentValues values = new ContentValues();
        values.put(RecyclerDatabaseHelper.COLUMN_WEIGHT, weight);
        values.put(RecyclerDatabaseHelper.COLUMN_DATE, date);

        // Update the record with the specified ID
        return database.update(RecyclerDatabaseHelper.TABLE_NAME, values,
                RecyclerDatabaseHelper.COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
    }

    // Delete method for deleting
    public int deleteWeightAndDate(long id) {
        // Delete the record with the specified ID
        int result = database.delete(
                RecyclerDatabaseHelper.TABLE_NAME,
                RecyclerDatabaseHelper.COLUMN_ID + " = ?",
                new String[]{String.valueOf(id)}
        );

        // Log the result
        Log.d("Database", "Deleted record with ID: " + id + ", result: " + result);

        return result;
    }

    public Cursor getWeightAndDateCursor() {
        // Select all columns from the table
        String[] projection = {
                RecyclerDatabaseHelper.COLUMN_ID,
                RecyclerDatabaseHelper.COLUMN_WEIGHT,
                RecyclerDatabaseHelper.COLUMN_DATE
        };
        return database.query(
                RecyclerDatabaseHelper.TABLE_NAME,  // Table name
                projection,  // Columns to retrieve
                null,  // Selection (null retrieves all rows)
                null,  // Selection arguments
                null,  // Group by
                null,  // Having
                null   // Order by

        );
    }
    // Add a method to get ID from Cursor
    public long getIdFromCursor(Cursor cursor) {
        int columnIndex = cursor.getColumnIndexOrThrow(RecyclerDatabaseHelper.COLUMN_ID);
        return cursor.getLong(columnIndex);
    }

    public void logAllRecords() {
        Cursor cursor = getWeightAndDateCursor();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                long id = getIdFromCursor(cursor);
                String date = cursor.getString(cursor.getColumnIndexOrThrow(RecyclerDatabaseHelper.COLUMN_DATE));
                String weight = cursor.getString(cursor.getColumnIndexOrThrow(RecyclerDatabaseHelper.COLUMN_WEIGHT));

                Log.d("Database", "ID: " + id + ", Date: " + date + ", Weight: " + weight);
            } while (cursor.moveToNext());

            cursor.close();
        }
    }

}
