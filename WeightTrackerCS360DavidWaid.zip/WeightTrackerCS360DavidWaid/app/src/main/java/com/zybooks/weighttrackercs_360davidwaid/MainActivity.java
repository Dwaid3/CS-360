package com.zybooks.weighttrackercs_360davidwaid;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ArrayList<weightDataModel> weightDataModels = new ArrayList<>();
    private RecyclerDatabaseManager recyclerDatabaseManager;
    private weightRecyclerViewAdapter recyclerAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RecyclerView recyclerView = findViewById(R.id.dataRecyclerView);

        //Settings listeners for add button
        ImageButton smsButton = findViewById(R.id.smsButton);
        Button addButton = findViewById(R.id.addDataButton);
        smsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Check and request SMS permission if needed
                if (checkAndRequestSmsPermission()) {
                    // Permission granted, send SMS
                    sendSMS("Access Granted best of luck!"); //
                } else {
                    // Permission not granted, handle accordingly
                    Toast.makeText(MainActivity.this, "SMS permission denied", Toast.LENGTH_SHORT).show();
                }
            }
        });

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Call a method in RecyclerDatabaseManager to handle add action
                // Pass the new date and weight to be added
                showAddDialog();



            }

        });


        //Creating database manager and opening the database
        recyclerDatabaseManager = new RecyclerDatabaseManager(this);
        recyclerDatabaseManager.open(); // Open the database

        // Load data from the database and populate the ArrayList
        loadWeightDataFromDatabase();

        //Setting up the recycler
        recyclerAdapter = new weightRecyclerViewAdapter(this, weightDataModels, this);
        recyclerView.setAdapter(recyclerAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    public void loadWeightDataFromDatabase() {


        // Clear the existing data
        weightDataModels.clear();

        // Query the database for all records
        Cursor cursor = recyclerDatabaseManager.getWeightAndDateCursor();

        // Iterate through the cursor and populate the ArrayList
        if (cursor != null) {
            int dateIndex = cursor.getColumnIndex(RecyclerDatabaseHelper.COLUMN_DATE);
            int weightIndex = cursor.getColumnIndex(RecyclerDatabaseHelper.COLUMN_WEIGHT);
            int Id = cursor.getColumnIndex(RecyclerDatabaseHelper.COLUMN_ID);

            while (cursor.moveToNext()) {
                // Use getColumnIndexOrThrow to handle the case where the column is not found
                String date = cursor.getString(dateIndex);
                String weight = cursor.getString(weightIndex);
                int ID = cursor.getInt(Id);

                weightDataModels.add(new weightDataModel(weight, date, ID));

            }

            cursor.close(); // Close the cursor when done
        }
    }



    private AlertDialog addDialog;  // Declare a member variable to hold the dialog instance

    private boolean checkAndRequestSmsPermission(){
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            // Permission not granted, request it
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 123);
            return false;
        }
        // Permission already granted
        return true;

    }

    private void sendSMS(String message){
        String phoneNumber = "1234567890"; // Replace with your desired phone number

        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(phoneNumber, null, message, null, null);

        Toast.makeText(this, "SMS sent!", Toast.LENGTH_SHORT).show();
    }

    private void showAddDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add Weight Entry");

        // Set up the input layout
        View view = getLayoutInflater().inflate(R.layout.dialog_add_weight, null);
        builder.setView(view);

        // Get references to EditTexts in the dialog layout
        EditText editDate = view.findViewById(R.id.editTextDate);
        EditText editWeight = view.findViewById(R.id.editTextWeight);

        // Set up the buttons
        builder.setPositiveButton("Add", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Retrieve user input
                String newDate = editDate.getText().toString();
                String newWeight = editWeight.getText().toString();

                // Call a method in RecyclerDatabaseManager to handle add action
                recyclerDatabaseManager.insertWeightAndDate(newDate, newWeight);

                loadWeightDataFromDatabase();  // Update the dataset


             
                // Dismiss the dialog
                addDialog.dismiss();
            }

        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Dismiss the dialog
                addDialog.dismiss();
            }
        });

        // Create the dialog and assign it to the member variable
        addDialog = builder.create();

        // Show the dialog
        addDialog.show();
    }









}