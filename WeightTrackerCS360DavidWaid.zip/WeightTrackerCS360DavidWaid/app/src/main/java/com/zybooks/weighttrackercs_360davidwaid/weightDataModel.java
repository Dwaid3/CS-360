package com.zybooks.weighttrackercs_360davidwaid;

public class weightDataModel {
    String dailyWeight;
    String currentDate;

    int ID;

    public weightDataModel(String dailyWeight, String currentDate, int ID) {
        this.dailyWeight = dailyWeight;
        this.currentDate = currentDate;
        this.ID = ID;
    }

    public String getDailyWeight() {
        return dailyWeight;
    }

    public String getCurrentDate() {
        return currentDate;
    }

    public int getId(){
        return ID;

    }
}
