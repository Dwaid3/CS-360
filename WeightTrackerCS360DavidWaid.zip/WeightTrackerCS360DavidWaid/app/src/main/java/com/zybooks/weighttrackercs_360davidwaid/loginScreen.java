package com.zybooks.weighttrackercs_360davidwaid;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;

public class loginScreen extends AppCompatActivity {
    private DatabaseManager databaseManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_screen);

        //Init DB manager
        databaseManager = new DatabaseManager(this);

        //find our buttons for creation and login
        Button createAccountButton = findViewById(R.id.createAcc);
        Button loginButton = findViewById(R.id.loginButton);

        //Listener for create an account button
        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createNewAccount();
            }
        });

        //Listener for login button
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginUser();
            }
        });
    }
    private void createNewAccount(){

        //Retrieve our text and put it into a string form
        EditText usernameEditText = findViewById(R.id.userName);
        EditText passwordEditText = findViewById(R.id.passWord);

        String userName = usernameEditText.getText().toString();
        String passWord = passwordEditText.getText().toString();

        //Insert the new account into the database
        databaseManager.open();
        long userId = databaseManager.insertUser(userName, passWord);
        databaseManager.close();

        //Shows message saying account was create
        Toast.makeText(this, "Account created Succesfully!", Toast.LENGTH_SHORT).show();
    }

    private void loginUser(){
        //Retrieve username and password from EditText fields
        EditText usernameEditText = findViewById(R.id.userName);
        EditText passwordEditText = findViewById(R.id.passWord);

        //Gets text and converts it to a string
        String userName = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        //Check user credentials in the DB
        boolean isValidCredentials = databaseManager.checkUser(userName, password);

        // Login successful
        if (isValidCredentials){
            Toast.makeText(this,"Login succesful!", Toast.LENGTH_SHORT).show();

            //If successful move into the application
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        else {
            // Login failed
            Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
        }
    }
}
