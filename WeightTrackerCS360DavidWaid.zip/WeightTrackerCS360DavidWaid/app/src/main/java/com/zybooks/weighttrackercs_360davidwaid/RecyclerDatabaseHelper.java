package com.zybooks.weighttrackercs_360davidwaid;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class RecyclerDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "user_weight.db";
    private static final int DATABASE_VERSION = 1;

    protected static final String TABLE_NAME = "user_weight";
    protected static final String COLUMN_ID = "id";
    protected static final String COLUMN_DATE = "date";
    protected static final String COLUMN_WEIGHT = "weight";

    public RecyclerDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    private static final String CREATE_TABLE =
            "CREATE TABLE " + TABLE_NAME + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_DATE + " TEXT, " +
                    COLUMN_WEIGHT + " TEXT)";

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
