package com.zybooks.weighttrackercs_360davidwaid;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class weightRecyclerViewAdapter extends RecyclerView.Adapter<weightRecyclerViewAdapter.MyViewHolder> {
    Context context;
    private MainActivity mainActivity;
    ArrayList<weightDataModel> weightModels;
    public weightRecyclerViewAdapter(Context context, ArrayList<weightDataModel> weightDataList, MainActivity mainActivity){
        this.context = context;
        this.weightModels = weightDataList;
        this.mainActivity = mainActivity;
    }


    @NonNull
    @Override
    public weightRecyclerViewAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.recycler_row_delete, parent,false);
        //Inflating our layout(Giving a look to our rows)

        return new weightRecyclerViewAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull weightRecyclerViewAdapter.MyViewHolder holder, int position) {
        //Assigns values to the view we created in the layoutfile
        //base on the position of hte recycler view
        holder.displayWeight.setText(weightModels.get(position).getDailyWeight());
        holder.displayDate.setText(weightModels.get(position).getCurrentDate());

        //Set click listeners for our edit and delete buttons

        holder.editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int adapterPOS = holder.getAdapterPosition();
                showEditDialog(adapterPOS);

            }
        });

        holder.deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int adapterPOS = holder.getAdapterPosition();
                handleDeleteAction(adapterPOS);
            }
        });
    }

    @Override
    public int getItemCount() {
        return weightModels.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{
        //Grabbing the views from layout file
        TextView displayWeight, displayDate;
        Button editButton, deleteButton;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            displayWeight = itemView.findViewById(R.id.displayData);
            displayDate = itemView.findViewById(R.id.displayDate);
            editButton = itemView.findViewById(R.id.editButton);
            deleteButton = itemView.findViewById(R.id.deleteButton);

        }
    }

    private void showEditDialog(final int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Edit Weight");

        // Set up the input
        final EditText input = new EditText(context);
        input.setInputType(InputType.TYPE_CLASS_NUMBER); // Assuming weight is a number
        builder.setView(input);

        // Set up the buttons
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String newWeight = input.getText().toString();
                handleEditAction(position, newWeight);
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }

    private void handleEditAction(int position, String newWeight) {
        Log.d("EditAction", "Position: " + position + ", New Weight: " + newWeight);
        // Retrieve the data from the dataset based on the position
        weightDataModel selectedData = weightModels.get(position);

        // Implement your logic for handling the edit action
        // You can call the updateWeightAndDate method from your DatabaseManager
        RecyclerDatabaseManager databaseManager = new RecyclerDatabaseManager(context);
        databaseManager.open();
        int rowsAffected = databaseManager.updateWeightAndDate(selectedData.getId(), selectedData.getCurrentDate(), newWeight);
        databaseManager.close();



        // Check the rowsAffected value to verify if the update was successful
        if (rowsAffected >= 0) {
            mainActivity.loadWeightDataFromDatabase();

            Log.d("Row edited", "Row:" + position);
            // Update your dataset with the new data if needed

            // Notify the adapter about the change
            notifyItemChanged(position);
            notifyDataSetChanged();



        }

    }
    // Method to handle the delete action
    private void handleDeleteAction(int position) {
        Log.d("DeleteAction", "Position: " + position);

        // Retrieve the data from the dataset based on the position
        weightDataModel selectedData = weightModels.get(position);
        Log.d("DeleteAction", "Deleting item with ID: " + selectedData.getId());
        // Implement your logic for handling the delete action, e.g., show a confirmation dialog
        // You can call the deleteWeightAndDate method from your DatabaseManager
        RecyclerDatabaseManager databaseManager = new RecyclerDatabaseManager(context);
        databaseManager.open();
        int rowsAffected = databaseManager.deleteWeightAndDate(selectedData.getId());
        databaseManager.close();

        // Check the rowsAffected value to verify if the delete was successful
        if (rowsAffected > 0) {
            // Remove the item from your dataset
            weightModels.remove(position);
            // Notify the adapter about the removal
            notifyItemRemoved(position);


        }
    }
    // Add a method to update the dataset
    public void updateDataSet(ArrayList<weightDataModel> newDataSet) {
        weightModels.clear();
        weightModels.addAll(newDataSet);
        notifyDataSetChanged();
    }


}
